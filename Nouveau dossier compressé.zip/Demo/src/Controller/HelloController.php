<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HelloController extends AbstractController
{
    /**
     * @Route("helloParam/{id}",requirements={"id"="\d+"},methods={"GET"})
     *
     * @return Response
     */
    public function HelloParam($id)
    {
        $titre = "Param Request";
        dump($id);
        return $this->render("helloParam.html.twig",["title"=>$titre,"type"=>"Any","param"=>$id]);
    }
    /**
     * @Route("helloRequest")
     *
     * @return Rerponse
     */
    public function helloRequest(Request $resquest)
    {
        
        $params = $resquest->query->all();
        dump($params);
        return  $this->render('base.html.twig');
    }
    
    /**
     * @Route("baseTwig")
     *
     * @return Response
     */
    public function baseTwig()
    {
        $titre = "Mon titre";
        $params = [
            "Oliver",
            "Marie",
            "Nicolas",
        ];
        dump($params);
        return $this->render("hello.html.twig",["title"=>$titre,"items"=>$params]);
    }


    /**
     * @Route("hello")
     * 
     *  @return Response
     */
    public function index()
    {
        return new Response('hello world bis !!');
    }
    
}
